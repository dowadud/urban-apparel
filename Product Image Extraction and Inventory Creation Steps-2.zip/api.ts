import { db } from './firebase';
import { collection, getDocs, getDoc, doc, query, where, addDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { Product, CartItem, Order } from './types';

// Products
export async function getProducts(): Promise<Product[]> {
  const productsCollection = collection(db, 'products');
  const productsSnapshot = await getDocs(productsCollection);
  
  return productsSnapshot.docs.map(doc => {
    const data = doc.data();
    return {
      id: doc.id,
      name: data.name,
      collection: data.collection,
      description: data.description,
      price: data.price,
      images: data.images,
      sizes: data.sizes,
      colors: data.colors,
      featured: data.featured,
      createdAt: data.createdAt.toDate()
    } as Product;
  });
}

export async function getProductsByCollection(collectionName: 'godspeed' | 'adg'): Promise<Product[]> {
  const productsCollection = collection(db, 'products');
  const q = query(productsCollection, where('collection', '==', collectionName));
  const productsSnapshot = await getDocs(q);
  
  return productsSnapshot.docs.map(doc => {
    const data = doc.data();
    return {
      id: doc.id,
      name: data.name,
      collection: data.collection,
      description: data.description,
      price: data.price,
      images: data.images,
      sizes: data.sizes,
      colors: data.colors,
      featured: data.featured,
      createdAt: data.createdAt.toDate()
    } as Product;
  });
}

export async function getFeaturedProducts(): Promise<Product[]> {
  const productsCollection = collection(db, 'products');
  const q = query(productsCollection, where('featured', '==', true));
  const productsSnapshot = await getDocs(q);
  
  return productsSnapshot.docs.map(doc => {
    const data = doc.data();
    return {
      id: doc.id,
      name: data.name,
      collection: data.collection,
      description: data.description,
      price: data.price,
      images: data.images,
      sizes: data.sizes,
      colors: data.colors,
      featured: data.featured,
      createdAt: data.createdAt.toDate()
    } as Product;
  });
}

export async function getProductById(id: string): Promise<Product | null> {
  const productDoc = doc(db, 'products', id);
  const productSnapshot = await getDoc(productDoc);
  
  if (!productSnapshot.exists()) {
    return null;
  }
  
  const data = productSnapshot.data();
  return {
    id: productSnapshot.id,
    name: data.name,
    collection: data.collection,
    description: data.description,
    price: data.price,
    images: data.images,
    sizes: data.sizes,
    colors: data.colors,
    featured: data.featured,
    createdAt: data.createdAt.toDate()
  } as Product;
}

// Orders
export async function createOrder(order: Omit<Order, 'id' | 'createdAt'>): Promise<string> {
  const ordersCollection = collection(db, 'orders');
  const orderData = {
    ...order,
    createdAt: new Date()
  };
  
  const docRef = await addDoc(ordersCollection, orderData);
  return docRef.id;
}

export async function getOrderById(id: string): Promise<Order | null> {
  const orderDoc = doc(db, 'orders', id);
  const orderSnapshot = await getDoc(orderDoc);
  
  if (!orderSnapshot.exists()) {
    return null;
  }
  
  const data = orderSnapshot.data();
  return {
    id: orderSnapshot.id,
    items: data.items,
    total: data.total,
    customerInfo: data.customerInfo,
    status: data.status,
    createdAt: data.createdAt.toDate()
  } as Order;
}

export async function updateOrderStatus(id: string, status: Order['status']): Promise<void> {
  const orderDoc = doc(db, 'orders', id);
  await updateDoc(orderDoc, { status });
}
