// Types for our product data
export interface Product {
  id: string;
  name: string;
  collection: 'godspeed' | 'adg';
  description: string;
  price: number;
  images: string[];
  sizes: string[];
  colors: string[];
  featured?: boolean;
  createdAt: Date;
}

export interface CartItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  size: string;
  color: string;
  image: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  customerInfo: {
    name: string;
    email: string;
    address: string;
  };
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  createdAt: Date;
}
