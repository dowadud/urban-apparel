# Urban Apparel - Next.js E-commerce Platform

Urban Apparel is a modern e-commerce platform built with Next.js and Firebase, featuring a dark, urban aesthetic inspired by brands like Hellstar and Gallery Dept. The platform is designed for the 15-28 year old demographic with bold typography and oversized visuals.

## Features

- Responsive design for all devices
- Dark urban aesthetic with bold typography
- Product collections (Godspeed and ADG)
- Product detail pages with size/color selection
- Shopping cart functionality with localStorage persistence
- Checkout flow
- Firebase integration for product data and orders

## Tech Stack

- Next.js 15
- TypeScript
- Tailwind CSS
- Firebase (Firestore, Auth, Storage)
- Vercel Deployment

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/urban-apparel.git
cd urban-apparel
```

2. Install dependencies
```bash
npm install
# or
yarn install
```

3. Set up environment variables
Create a `.env.local` file in the root directory with the following variables:
```
NEXT_PUBLIC_FIREBASE_API_KEY=your_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_auth_domain
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_storage_bucket
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_messaging_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_app_id
NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID=your_measurement_id
```

4. Run the development server
```bash
npm run dev
# or
yarn dev
```

5. Open [http://localhost:3000](http://localhost:3000) in your browser

## Deployment

The application is configured for easy deployment to Vercel:

1. Push your code to GitHub
2. Connect your GitHub repository to Vercel
3. Configure the environment variables in Vercel
4. Deploy

## Project Structure

```
urban-apparel/
├── public/              # Static assets
│   └── images/          # Product and UI images
├── src/
│   ├── app/             # Next.js App Router pages
│   │   ├── cart/        # Shopping cart page
│   │   ├── checkout/    # Checkout page
│   │   ├── collections/ # Collection pages
│   │   │   ├── godspeed/
│   │   │   └── adg/
│   │   ├── products/    # Product pages
│   │   │   └── [id]/    # Dynamic product detail page
│   │   ├── globals.css  # Global styles
│   │   ├── layout.tsx   # Root layout with CartProvider
│   │   └── page.tsx     # Homepage
│   ├── components/      # Reusable components
│   │   ├── Navbar.tsx
│   │   └── Footer.tsx
│   └── lib/             # Utility functions and hooks
│       ├── api.ts       # Firebase API functions
│       ├── cart-context.tsx # Cart context provider
│       ├── firebase.ts  # Firebase configuration
│       └── types.ts     # TypeScript types
├── tailwind.config.js   # Tailwind CSS configuration
└── next.config.js       # Next.js configuration
```

## Firebase Setup

1. Create a new Firebase project at [firebase.google.com](https://firebase.google.com)
2. Enable Firestore, Authentication, and Storage
3. Create the following collections in Firestore:
   - `products`: For storing product information
   - `orders`: For storing order information
4. Set up Firebase Authentication methods as needed

## Environment Variables

The following environment variables are required:

| Variable | Description |
|----------|-------------|
| NEXT_PUBLIC_FIREBASE_API_KEY | Firebase API Key |
| NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN | Firebase Auth Domain |
| NEXT_PUBLIC_FIREBASE_PROJECT_ID | Firebase Project ID |
| NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET | Firebase Storage Bucket |
| NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID | Firebase Messaging Sender ID |
| NEXT_PUBLIC_FIREBASE_APP_ID | Firebase App ID |
| NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID | Firebase Measurement ID |

## License

This project is licensed under the MIT License.
